我的Firefox扩展总结
###################
:date: 2012-03-01 13:50
:category: IT技术
:tags: Firefox, 总结, 扩展
:slug: firefox-addon

一、浏览优化类

    #. Adblock Plus               清除广告就靠它了。
    #. AutoPager                   
       自动翻页。不想成为鼠标手？该插件必装。
    #. Flashblock                   
       加快网页加载速度，屏蔽恼人的flash广告和自动播放功能
    #. GreaseMonkey           用脚本实现对个别站点的自定义配置
    #. Stylish                           
       与GreaseMonkey类似，自定义CSS。GR的新界面很低效，配合该插件可以完美解决。
    #. iReader                         
       重新布局文章，优化浏览体验。较少适用，需要网页符合规范。

二、下载工具类

    #. DownThemAll                     
       坚守FF的原因之一，非常稳定高速的下载体验
    #. DownloadStatusbar            下载状态查看，必备的基本扩展
    #. NetVideoHunter                  在线视频下载利器
    #. FlashVideoDownloader   
       除了下载视频外，更强大的地方在于可以下载flash

三、云同步类

    #. Xmarks                         一流的书签管理，多浏览器同步
    #. LastPass                      
       Xmarks的兄弟产品，在线密码管理，简化登录步骤
    #. ReadItLater              
       一键收藏，想快速离开电脑回到工作，必备扩展
    #. Evernote Web Clipper        Evernote是最强大的PKM软件，没有之一
    #. Delicious Bookmarks          书签分享，社交功能强大
    #. Gmarks                                     
       Google书签产品，某些方面输于Delicious
    #. SpringPad                                类似Evernote的PKM服务

四、工具类

    #. Firebug                         
       试用过几次，非常强大的网页调试工具
    #. ScribeFire                    
       博客发布工具，目前跨平台博客发布工具首选
    #. AutoProxy                   代理工具，易用而强大

.. raw:: html

   </p>

